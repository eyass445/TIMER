//
//  MyViwe.swift
//  Timer
//
//  Created by eyas seyam on 3/11/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import UIKit
@IBDesignable
class MyViwe: UIView {

    @IBInspectable var FirstColor:  UIColor = UIColor.clear{
        didSet {
            UpDeteView()
        }
    }
    
    @IBInspectable var LirstColor:  UIColor = UIColor.clear{
        didSet {
            UpDeteView()
        }
    }
    
    
    override class var layerClass : AnyClass {
        get {
            return CAGradientLayer.self
        }
    }
    
    
    func UpDeteView() {
        let Layer = self.layer as! CAGradientLayer
        Layer.colors = [FirstColor.cgColor , LirstColor.cgColor]
        
    }
    
}
