//
//  ViewController.swift
//  Timer
//
//  Created by eyas seyam on 3/11/19.
//  Copyright © 2019 eyas seyam. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController , UITableViewDataSource , UITableViewDelegate{
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell()
        cell.textLabel?.text = Names[indexPath.row]
        return cell
        
    }
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        MyViwe.layer.cornerRadius = 20
        myTableView.delegate = self
        myTableView.dataSource = self
        timer2 = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.FetchDate), userInfo: nil, repeats: true)
    }
    
    
    
    
    
    
    @IBOutlet weak var PauseOutLet: UIButton!
    @IBOutlet weak var TimerLable: UILabel!
    @IBOutlet weak var MyViwe: MyViwe!
    @IBOutlet weak var myStartConst: NSLayoutConstraint!
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var myConstTable: NSLayoutConstraint!
    @IBOutlet weak var myTableViewView: MyViwe!
    
    
    
    
    
    
    var timer : Timer?
    var timer2 : Timer?
    var seconds=0
    var nameTF : UITextField?
    var tasksMO = [NSManagedObject]()
    var Names = [String]()
    
    
    
    
    
    
    
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return UITableViewCell.EditingStyle.delete
    }
    
    
    
     
    
    
    
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            Context.delete(tasksMO[indexPath.row])
            do {
                try Context.save()
                self.Names.remove(at: indexPath.row)
                myTableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.fade)
            } catch {
                
                print("Error")
                
            }
        }
    }
    
    
    
    
    
    
    
    
    
    
    @IBAction func MyTaskAction(_ sender: Any) {
        
        myConstTable.constant = 0
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
        }
        
        
        
    }
    
    
    
    
    
    @objc func FetchDate() {
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Tasks")
        do {
            let results = try Context.fetch(request)
            tasksMO = results as! [NSManagedObject]
            for taskmo in tasksMO {
                Names.append(taskmo.value(forKey: "name") as! String)
                myTableView.reloadData()
            }
        } catch {
            
        }
    }
    
    
    
    
    
    
    
    
    
    
    @IBAction func startActhin(_ sender: Any) {
        myStartConst.constant = 0
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
        }
        RunTimer()

    }
    
    
    
    
    
    
    
    
    func TimerString (time : TimeInterval) -> String {
        let houers = Int(time) / 3600
        let minets  = Int(time) / 60 % 60
        let soucand = Int(time) % 60
        return String(format: "%02i:%02i:%02i", houers,minets,soucand)
        
        
    }
    
    
    
    
    
    
    @objc func UpdeteTime (){
        seconds += 1
        TimerLable.text = TimerString(time: TimeInterval(seconds))
    
    }
    
    
    
    
    
    
    func RunTimer (){
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector ( ViewController.UpdeteTime ), userInfo: nil, repeats: true)
    }
    
    
    
    
    
    
    
    @IBAction func StopBut(_ sender: Any) {
        timer?.invalidate()
        seconds = 0
        TimerLable.text = TimerString(time: TimeInterval(seconds) )
        PauseOutLet.setTitle("start", for: .normal)
        AlertControlar()
    }
    
    
    
    
    
    
    
    func AlertControlar () {
        let alertCon = UIAlertController(title: "Write Your Task ", message: "Enter Your task name", preferredStyle: .alert)
        
        alertCon.addTextField { (nameTF) in
            nameTF.placeholder = "Name"
            self.nameTF = nameTF
        
        let AlertAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        alertCon.addAction(AlertAction)
            
            let AlertAction2 = UIAlertAction(title: "Save", style: .default, handler: { (action) in
                self.SaveDateFORCoteDate()
            })
            
        alertCon.addAction(AlertAction2)
        self.present(alertCon, animated: true, completion: nil)
        }}
    

    
    
    
    
    
    func SaveDateFORCoteDate () {
        let entity = NSEntityDescription.entity(forEntityName: "Tasks", in: Context)
        let task = NSManagedObject(entity: entity!, insertInto: Context)
        task.setValue(nameTF?.text, forKey: "name")
        do {
            try Context.save()
            let AlertCon = UIAlertController(title: "Saved", message: "Your task \(nameTF!.text!) was Saved ", preferredStyle: .alert)
           
            let AlertAction = UIAlertAction(title: "OK", style: .default) { (action) in
                self.myConstTable.constant=0
                UIView.animate(withDuration: 0.3, animations: {
                    self.view.layoutIfNeeded()
                })
            }
            AlertCon.addAction(AlertAction)
            
            self.present(AlertCon, animated: true, completion: nil)
            
            

            
        } catch {
            
            let AlertCon = UIAlertController(title: "Error", message: "did not saved ", preferredStyle: .alert)
            
             let AlertAction = UIAlertAction(title: "OK", style: .default, handler: nil)
          
            
            AlertCon.addAction(AlertAction)
            
            self.present(AlertCon, animated: true, completion: nil)
            
            
        }
            }
    
    
    @IBAction func puseBut(_ sender: Any) {
        if  PauseOutLet.titleLabel?.text == "Pause" {
            timer?.invalidate()
            PauseOutLet.setTitle("start", for: .normal)

        }
        else if PauseOutLet.titleLabel?.text == "start" {
            PauseOutLet.setTitle("Pause", for: .normal)
            RunTimer()

        }
    }
    
   
    //عند الضغط ع الشاشة او اللمس تختفي الشاشة بشكل انميشن بسرعة ثانية واحدة
    
        override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            myConstTable.constant = 360
            UIView.animate(withDuration: 0.1) {
                self.view.layoutIfNeeded()
            }
        }

}


